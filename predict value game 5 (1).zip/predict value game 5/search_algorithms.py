import unittest
from gamemenu import binary_search, jump_search, exponential_search, fibonacci_search, interpolation_search

class TestSearchAlgorithms(unittest.TestCase):
    
    def setUp(self):
       
        self.arr = list(range(1, 10001))  # Example sorted list
    
    def test_binary_search(self):
        self.assertEqual(binary_search(self.arr, 5000), 4999)  # Index starts from 0
    
    def test_jump_search(self):
        self.assertEqual(jump_search(self.arr, 5000), 4999)
    
    def test_exponential_search(self):
        self.assertEqual(exponential_search(self.arr, 5000), 4999)
    
    def test_fibonacci_search(self):
        self.assertEqual(fibonacci_search(self.arr, 5000), 4999)
    
    def test_interpolation_search(self):
        self.assertEqual(interpolation_search(self.arr, 5000), 4999)

if __name__ == '__main__':
    unittest.main()
