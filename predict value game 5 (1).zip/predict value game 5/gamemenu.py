import random
import time
import sqlite3

from flask import Flask, render_template, jsonify, request 
import random

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')




@app.route('/start_game', methods=['GET'])
def start_game():
    numbers = sorted(random.sample(range(1, 1000001), 5000))
    target = random.choice(numbers)
    correct_index = numbers.index(target)
    options = random.sample(numbers, 3)
    if correct_index not in options:
        options.append(correct_index)
    random.shuffle(options)
    return jsonify({"target": target, "correctIndex": correct_index, "options": options})

@app.route('/save_result', methods=['POST'])
def save_result():
    data = request.json
    name = data['name']
    target = data['target']
    index = data['index']
    time = data['time']
    return "Result saved successfully"

if __name__ == '__main__':
    app.run(debug=True)


@app.route('/start_game', methods=['GET'])
def start_game():
    numbers = sorted(random.sample(range(1, 1000001), 5000))
    target = random.choice(numbers)

    
    correct_index = numbers.index(target)

    # Generate some random options
    options = random.sample(numbers, 3)
    if correct_index not in options:
        options.append(correct_index)
    random.shuffle(options)

    return jsonify({
        "target": target,
        "correctIndex": correct_index,
        "options": options
    })

@app.route('/save_result', methods=['POST'])
def save_result():
    data = request.json
    name = data['name']
    target = data['target']
    index = data['index']
    time= data['time']

  
    return "Result saved successfully"

if __name__ == "__main__":
    app.run(debug=True)

def display_menu():
    print("Welcome to Predict the Value Index Game!")
    print("1. Play Game")
    print("2. Exit")

def get_user_choice():
    choice = input("Enter your choice: ")
    return choice

def generate_random_numbers():
    return sorted(random.sample(range(1, 1000001), 5000))

def binary_search(arr, x):
    low, high = 0, len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] < x:
            low = mid + 1
        elif arr[mid] > x:
            high = mid - 1
        else:
            return mid
    return -1

import math

def jump_search(arr, x):
    n = len(arr)
    step = int(math.sqrt(n))
    prev = 0
    
    while arr[min(step, n) - 1] < x:
        prev = step
        step += int(math.sqrt(n))
        if prev >= n:
            return -1
    
    for i in range(prev, min(step, n)):
        if arr[i] == x:
            return i
    return -1

def exponential_search(arr, x):
    if arr[0] == x:
        return 0
    i = 1
    while i < len(arr) and arr[i] <= x:
        i = i * 2
    return binary_search(arr[:min(i, len(arr))], x)


def fibonacci_search(arr, x):
    fib_m2 = 0
    fib_m1 = 1
    fib_m = fib_m1 + fib_m2
    
    while fib_m < len(arr):
        fib_m2 = fib_m1
        fib_m1 = fib_m
        fib_m = fib_m1 + fib_m2
    
    offset = -1
    
    while fib_m > 1:
        i = min(offset + fib_m2, len(arr) - 1)
        if arr[i] < x:
            fib_m = fib_m1
            fib_m1 = fib_m2
            fib_m2 = fib_m - fib_m1
            offset = i
        elif arr[i] > x:
            fib_m = fib_m2
            fib_m1 = fib_m1 - fib_m2
            fib_m2 = fib_m - fib_m1
        else:
            return i
    if fib_m1 and arr[offset + 1] == x:
        return offset + 1
    return -1


def interpolation_search(arr, x):
    low = 0
    high = len(arr) - 1
    
    while low <= high and arr[low] <= x <= arr[high]:
        if low == high:
            if arr[low] == x:
                return low
            return -1
        
        pos = low + ((high - low) // (arr[high] - arr[low]) * (x - arr[low]))
        
        if arr[pos] == x:
            return pos
        if arr[pos] < x:
            low = pos + 1
        else:
            high = pos - 1
    
    return -1


def measure_search_time(search_fn, arr, x):
    start_time = time.time()
    index = search_fn(arr, x)
    end_time = time.time()
    elapsed_time = end_time - start_time
    return index, elapsed_time


def play_game():
    numbers = generate_random_numbers()
    target = random.choice(numbers)
    print("Random number selected. Please predict its index:")
    
    search_algorithms = {
        "Binary Search": binary_search,
        "Jump Search": jump_search,
        "Exponential Search": exponential_search,
        "Fibonacci Search": fibonacci_search,
        "Interpolation Search": interpolation_search
    }
    
    results = {}
    
    for name, func in search_algorithms.items():
        index, elapsed_time = measure_search_time(func, numbers, target)
        results[name] = {"index": index, "time": elapsed_time}
        print(f"{name}: Index = {index}, Time = {elapsed_time:.6f} seconds")
    
    print(f"Choose the correct index for the number {target} from the following options:")
    options = random.sample([result["index"] for result in results.values()], 3)
    if results["Binary Search"]["index"] not in options:
        options.append(results["Binary Search"]["index"])
    random.shuffle(options)
    
    for i, option in enumerate(options, 1):
        print(f"{i}. {option}")
    
    choice = int(input("Your choice: ")) - 1
    correct = options[choice] == results["Binary Search"]["index"]
    
    if correct:
        name = input("You got it right! Enter your name: ")
        save_result(name, target, results["Binary Search"]["index"])
        print("Result saved to the database.")
    else:
        print("Wrong answer. Better luck next time!")

def save_result(name, target, index):
    conn = sqlite3.connect('game_results.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS results 
                      (name TEXT, target INTEGER, index_value INTEGER)''')
    cursor.execute("INSERT INTO results (name, target, index_value) VALUES (?, ?, ?)", (name, target, index))
    conn.commit()
    conn.close()



@app.route('/start_game', methods=['GET'])
def start_game():
    numbers = sorted(random.sample(range(1, 1000001), 5000))
    target = random.choice(numbers)
    correct_index = numbers.index(target)

    
    search_results = {
        "Binary Search": measure_search_time(binary_search, numbers, target),
        "Jump Search": measure_search_time(jump_search, numbers, target),
        "Exponential Search": measure_search_time(exponential_search, numbers, target),
        "Fibonacci Search": measure_search_time(fibonacci_search, numbers, target),
        "Interpolation Search": measure_search_time(interpolation_search, numbers, target)
    }

    options = random.sample(numbers, 3)
    if correct_index not in options:
        options.append(correct_index)
    random.shuffle(options)

    return jsonify({
        "target": target,
        "correctIndex": correct_index,
        "options": options,
        "searchResults": {k: {"index": v[0], "time": v[1]} for k, v in search_results.items()}
    })




def main():
    while True:
        display_menu()
        choice = get_user_choice()
        if choice == '1':
            play_game()
        elif choice == '2':
            print("Exiting the game. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
