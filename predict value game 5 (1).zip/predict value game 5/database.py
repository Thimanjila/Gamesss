import unittest
import sqlite3

class TestDatabase(unittest.TestCase):

    def setUp(self):
        
        self.conn = sqlite3.connect('game_results.db')
        self.cursor = self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS results 
                               (name TEXT, target INTEGER, index_value INTEGER)''')
    
    def test_save_result(self):
        
        name = "Alice"
        target = 5000
        index_value = 4999
        self.cursor.execute("INSERT INTO results (name, target, index_value) VALUES (?, ?, ?)", 
                            (name, target, index_value))
        self.conn.commit()
        
        
        self.cursor.execute("SELECT * FROM results WHERE name=?", (name,))
        result = self.cursor.fetchone()
        
        
        self.assertEqual(result, (name, target, index_value))
    
    def tearDown(self):
        
        self.conn.close()

if __name__ == '__main__':
    unittest.main()
