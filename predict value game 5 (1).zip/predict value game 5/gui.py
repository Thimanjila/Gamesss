import tkinter as tk
from tkinter import messagebox
import random
import time
import sqlite3



def binary_search(arr, x):
    low, high = 0, len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] < x:
            low = mid + 1
        elif arr[mid] > x:
            high = mid - 1
        else:
            return mid
    return -1

def jump_search(arr, x):
    n = len(arr)
    step = int(n**0.5)
    prev = 0
    while arr[min(step, n) - 1] < x:
        prev = step
        step += int(n**0.5)
        if prev >= n:
            return -1
    for i in range(prev, min(step, n)):
        if arr[i] == x:
            return i
    return -1

def exponential_search(arr, x):
    if arr[0] == x:
        return 0
    i = 1
    while i < len(arr) and arr[i] <= x:
        i = i * 2
    return binary_search(arr[:min(i, len(arr))], x)

def fibonacci_search(arr, x):
    fib_m2 = 0
    fib_m1 = 1
    fib_m = fib_m1 + fib_m2
    while fib_m < len(arr):
        fib_m2 = fib_m1
        fib_m1 = fib_m
        fib_m = fib_m1 + fib_m2
    offset = -1
    while fib_m > 1:
        i = min(offset + fib_m2, len(arr) - 1)
        if arr[i] < x:
            fib_m = fib_m1
            fib_m1 = fib_m2
            fib_m2 = fib_m - fib_m1
            offset = i
        elif arr[i] > x:
            fib_m = fib_m2
            fib_m1 = fib_m1 - fib_m2
            fib_m2 = fib_m - fib_m1
        else:
            return i
    if fib_m1 and arr[offset + 1] == x:
        return offset + 1
    return -1

def interpolation_search(arr, x):
    low = 0
    high = len(arr) - 1
    while low <= high and arr[low] <= x <= arr[high]:
        if low == high:
            if arr[low] == x:
                return low
            return -1
        pos = low + ((high - low) // (arr[high] - arr[low]) * (x - arr[low]))
        if arr[pos] == x:
            return pos
        if arr[pos] < x:
            low = pos + 1
        else:
            high = pos - 1
    return -1

def measure_search_time(search_fn, arr, x):
    start_time = time.time()
    index = search_fn(arr, x)
    end_time = time.time()
    elapsed_time = end_time - start_time
    return index, elapsed_time



class PredictValueGame(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Predict the Value Index Game")
        self.geometry("500x400")
        self.configure(bg="#2e3f4f") 

        # Main title label
        self.title_label = tk.Label(
            self, text="Predict the Value Index", font=("Arial", 20, "bold"),
            bg="#2e3f4f", fg="white"
        )
        self.title_label.pack(pady=20)

        # Button for playing the game
        self.play_button = tk.Button(
            self, text="Play Game", font=("Arial", 14), bg="#28a745", fg="white",
            activebackground="#218838", activeforeground="white", command=self.play_game
        )
        self.play_button.pack(pady=20)

        # Button for exiting the game
        self.exit_button = tk.Button(
            self, text="Exit", font=("Arial", 14), bg="#dc3545", fg="white",
            activebackground="#c82333", activeforeground="white", command=self.exit_game
        )
        self.exit_button.pack(pady=10)

    def play_game(self):
        
        
        # Generate random numbers and target
        self.numbers = sorted(random.sample(range(1, 1000001), 5000))
        self.target = random.choice(self.numbers)

        # Search algorithms and results
        search_algorithms = {
            "Binary Search": binary_search,
            "Jump Search": jump_search,
            "Exponential Search": exponential_search,
            "Fibonacci Search": fibonacci_search,
            "Interpolation Search": interpolation_search
        }

        self.results = {}
        for name, func in search_algorithms.items():
            index, elapsed_time = measure_search_time(func, self.numbers, self.target)
            self.results[name] = {"index": index, "time": elapsed_time}
            
            




        
        options = random.sample([result["index"] for result in self.results.values()], 3)
        correct_index = self.results["Binary Search"]["index"]
        if correct_index not in options:
            options.append(correct_index)
        random.shuffle(options)

        self.display_options(options)

    def display_options(self, options):
        self.clear_widgets()

        self.label = tk.Label(
            self, text=f"Guess the index for the number: {self.target}",
            font=("Arial", 16), bg="#2e3f4f", fg="white"
        )
        self.label.pack(pady=20)

        self.buttons_frame = tk.Frame(self, bg="#2e3f4f")
        self.buttons_frame.pack(pady=10)

        self.option_buttons = []
        for i, option in enumerate(options):
            button = tk.Button(
                self.buttons_frame, text=str(option), font=("Arial", 14), width=10,
                bg="#17a2b8", fg="white", activebackground="#138496",
                command=lambda opt=option: self.check_answer(opt)
            )
            button.grid(row=0, column=i, padx=10)
            self.option_buttons.append(button)

    def check_answer(self, selected_index):
        correct_index = self.results["Binary Search"]["index"]
        if selected_index == correct_index:
            self.label.config(text="Correct! Enter your name below:")
            self.name_entry = tk.Entry(self, font=("Arial", 14), width=20)
            self.name_entry.pack(pady=10)
            self.submit_button = tk.Button(
                self, text="Submit", font=("Arial", 14), bg="#ffc107", fg="black",
                activebackground="#e0a800", command=self.save_result
            )
            self.submit_button.pack(pady=10)
        else:
            messagebox.showerror("Incorrect", "Wrong answer. Try again!")

    def save_result(self):
        name = self.name_entry.get()
        target = self.target
        index = self.results["Binary Search"]["index"]

        # Save result in SQLite database
        conn = sqlite3.connect('game_results.db')
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS results 
                          (name TEXT, target INTEGER, index_value INTEGER)''')
        cursor.execute("INSERT INTO results (name, target, index_value) VALUES (?, ?, ?)", (name, target, index))
        conn.commit()
        conn.close()

        messagebox.showinfo("Success", "Result saved to the database!")
        self.reset_game()

    def reset_game(self):
        self.clear_widgets()
        self.label.config(text="Play again or exit.")
        self.play_button.pack(pady=20)
        self.exit_button.pack(pady=10)

    def exit_game(self):
        self.destroy()

    def clear_widgets(self):
        """Clear all the widgets before updating the UI."""
        for widget in self.winfo_children():
            if isinstance(widget, tk.Entry) or isinstance(widget, tk.Button):
                widget.pack_forget()


if __name__ == "__main__":
    game = PredictValueGame()
    game.mainloop()
