import tkinter as tk  
from tkinter import ttk, messagebox, simpledialog  
import sqlite3  
import time  

# Database functions  
def create_database():  
    conn = sqlite3.connect('hanoi.db')  
    c = conn.cursor()  
    c.execute('''CREATE TABLE IF NOT EXISTS games (  
                  player_name TEXT,  
                  num_disks INTEGER,  
                  moves INTEGER,  
                  time_taken REAL)''')  
    conn.commit()  
    conn.close()  

def save_game_data(player_name, num_disks, moves, time_taken):  
    conn = sqlite3.connect('hanoi.db')  
    c = conn.cursor()  
    c.execute("INSERT INTO games (player_name, num_disks, moves, time_taken) VALUES (?, ?, ?, ?)",   
              (player_name, num_disks, moves, time_taken))  
    conn.commit()  
    conn.close()  

class TowerOfHanoiApp:  
    def __init__(self, master):  
        self.master = master  
        self.master.title("Tower of Hanoi")  
        self.master.geometry("400x600")  
        self.master.configure(bg="#e0f7fa")  
        create_database()  
        
        self.moves = 0  
        self.num_disks = 0  
        self.pegs = {'A': [], 'B': [], 'C': []}  
        
        self.create_widgets()  

    def create_widgets(self):  
        title_label = ttk.Label(self.master, text="Tower of Hanoi", font=("Arial", 24, "bold"), background="#e0f7fa")  
        title_label.pack(pady=20)  

        self.disk_count_label = ttk.Label(self.master, text="Number of Disks:", background="#e0f7fa")  
        self.disk_count_label.pack(pady=10)  

        self.disk_count = tk.IntVar(value=3)  
        self.disk_count_spinbox = ttk.Spinbox(self.master, from_=1, to=10, textvariable=self.disk_count)  
        self.disk_count_spinbox.pack(pady=10)  

        self.start_button = ttk.Button(self.master, text="Start Game", command=self.start_game)  
        self.start_button.pack(pady=10)  

        self.moves_label = ttk.Label(self.master, text="Moves: 0", background="#e0f7fa")  
        self.moves_label.pack(pady=10)  

        self.peg_frames = []  
        for peg in ['A', 'B', 'C']:  
            peg_frame = ttk.Frame(self.master, width=100, height=400, relief=tk.RAISED, borderwidth=2)  
            peg_frame.pack(side=tk.LEFT, padx=20, pady=20)  
            self.peg_frames.append(peg_frame)  

    def start_game(self):  
        self.moves = 0  
        self.moves_label.config(text="Moves: 0")  
        self.num_disks = self.disk_count.get()  
        self.pegs = {'A': list(range(self.num_disks, 0, -1)), 'B': [], 'C': []}  
        self.update_disk_positions()  

    def update_disk_positions(self):  
        for peg_index, peg in enumerate(self.pegs.values()):  
            for i, disk in enumerate(peg):  
                disk_label = ttk.Label(self.peg_frames[peg_index], text=str(disk), font=("Arial", 16, "bold"),  
                                       background=f"#{(disk * 20):02x}{(disk * 20):02x}00",  
                                       foreground="white", padding=5)  
                disk_label.place(x=50 - i * 10, y=350 - i * 30)  

    def move_disk(self, start_peg, target_peg, disk):  
        if not self.pegs[target_peg] or self.pegs[target_peg][-1] > disk:  
            self.pegs[start_peg].remove(disk)  
            self.pegs[target_peg].append(disk)  
            self.moves += 1  
            self.moves_label.config(text=f"Moves: {self.moves}")  
            self.update_disk_positions()  
            self.check_win()  

    def check_win(self):  
        if len(self.pegs['C']) == self.num_disks:  
            end_time = time.time()  
            time_taken = end_time - self.start_time  
            save_game_data(self.player_name, self.num_disks, self.moves, time_taken)  
            messagebox.showinfo("Game Over", f"Congratulations! You completed the game in {time_taken:.2f} seconds.")  
            self.master.destroy()  

if __name__ == "__main__":  
    root = tk.Tk()  
    app = TowerOfHanoiApp(root)  
    root.mainloop()