from flask import Flask, render_template, request, jsonify
import random
import sqlite3
import time

app = Flask(__name__)

# Function to save result in the database
def save_result(target, correct_index, elapsed_time):
    conn = sqlite3.connect('game_results.db')
    cursor = conn.cursor()
    
    # Create table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS results (
            target INTEGER, 
            correct_index INTEGER,
            elapsed_time REAL
        )
    ''')
    
    # Insert result into the table
    cursor.execute('INSERT INTO results (target, correct_index, elapsed_time) VALUES (?, ?, ?)', 
                   (target, correct_index, elapsed_time))
    conn.commit()
    conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start_game', methods=['GET'])
def start_game():
    # Start the timer
    start_time = time.time()

    # Generate 5000 random numbers and sort them
    numbers = sorted(random.sample(range(1, 1000001), 5000))
    
    # Select a random target number
    target = random.choice(numbers)
    
    # Find the correct index of the target number
    correct_index = numbers.index(target)
    
    # Calculate the elapsed time
    end_time = time.time()
    elapsed_time = end_time - start_time
    

    # Save result to the database, including elapsed time
    save_result(target, correct_index, elapsed_time)
    
    # Return the result as JSON for further use
    return jsonify({
        'target': target, 
        'correct_index': correct_index,
        'elapsed_time': elapsed_time
    })

if __name__ == "__main__":
    app.run(debug=True)
