import unittest
from gamemenu import app  

class TestFlaskRoutes(unittest.TestCase):

    def setUp(self):
        
        self.app = app.test_client()
        self.app.testing = True
    
    def test_index_route(self):
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)
    
    def test_start_game_route(self):
        response = self.app.get('/start_game')
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn('target', data)
        self.assertIn('correctIndex', data)
        self.assertIn('options', data)
    
    def test_save_result_route(self):
        response = self.app.post('/save_result', json={
            "name": "John Doe",
            "target": 5000,
            "index": 4999,
            "time": 0.0025
        })
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data.decode(), "Result saved successfully")

if __name__ == '__main__':
    unittest.main()
