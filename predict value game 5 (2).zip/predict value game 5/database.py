from flask import Flask, render_template, request, jsonify
import random
import sqlite3
import time
import matplotlib.pyplot as plt

app = Flask(__name__)



# Connect to the SQLite database
conn = sqlite3.connect('game_data.db')
cur = conn.cursor()

# Fetch data from the table
cur.execute("SELECT player_name, score FROM game_results")
data = cur.fetchall()

# Separate data into x (player names) and y (scores) lists
players = [row[0] for row in data]
scores = [row[1] for row in data]

# Close the connection
conn.close()

# Plot a bar chart
plt.bar(players, scores, color='skyblue')
plt.xlabel('Player Name')
plt.ylabel('Score')
plt.title('Player Scores')
plt.show()


# Function to save result with time
def save_result(name, target, correct_index, elapsed_time):
    conn = sqlite3.connect('game_results.db')
    cursor = conn.cursor()
    
    # Create table if it doesn't exist, including the 'time' column
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS results (
            name TEXT, 
            target INTEGER, 
            index_value INTEGER,
            time REAL
        )
    ''')
    
    # Insert the result with the time into the table
    cursor.execute('INSERT INTO results (name, target, index_value, time) VALUES (?, ?, ?, ?)', 
                   (name, target, correct_index, elapsed_time))
    
    conn.commit()
    conn.close()

# Route to render the game page (if using a template)
@app.route('/')
def index():
    return render_template('index.html')

# Route to start the game and measure the time taken for the search
@app.route('/start_game', methods=['GET'])
def start_game():
    # Start the timer
    start_time = time.time()

    # Generate 5000 random numbers and sort them
    numbers = sorted(random.sample(range(1, 1000001), 5000))
    
    # Select a random target number
    target = random.choice(numbers)
    
    # Find the correct index of the target number
    correct_index = numbers.index(target)
    
    # Calculate the elapsed time
    end_time = time.time()
    elapsed_time = end_time - start_time

    # Save the result to the database, including the elapsed time
    save_result('player_name', target, correct_index, elapsed_time)
    
    # Return the result as JSON for further use in frontend
    return jsonify({
        'target': target, 
        'correct_index': correct_index,
        'elapsed_time': elapsed_time
    })
    
    

if __name__ == "__main__":
    app.run(debug=True)
