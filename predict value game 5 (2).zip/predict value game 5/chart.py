import tkinter as tk
from tkinter import ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import sqlite3

# Function to display chart
def show_chart():
    conn = sqlite3.connect('game_data.db')
    cur = conn.cursor()
    cur.execute("SELECT player_name, score FROM game_results")
    data = cur.fetchall()
    conn.close()

    players = [row[0] for row in data]
    scores = [row[1] for row in data]

    # Create Matplotlib Figure
    fig, ax = plt.subplots()
    ax.bar(players, scores, color='lightblue')
    ax.set_xlabel('Players')
    ax.set_ylabel('Scores')
    ax.set_title('Player Scores')

    # Embed the Matplotlib plot into Tkinter
    canvas = FigureCanvasTkAgg(fig, master=root) 
    canvas.draw()
    canvas.get_tk_widget().pack()

# Create the main Tkinter window
root = tk.Tk()
root.title('Game Chart')

# Create a button to display the chart
btn = ttk.Button(root, text='Show Chart', command=show_chart)
btn.pack()

# Start the Tkinter event loop
root.mainloop()
