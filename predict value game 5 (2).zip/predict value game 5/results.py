import sqlite3

def check_results():
    conn = sqlite3.connect('game_results.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM results")
    rows = cursor.fetchall()
    for row in rows:
        print(row)
    conn.close()

check_results()
